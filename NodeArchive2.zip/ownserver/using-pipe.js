import fs  from 'fs';
const path = '/Users/amitsrivastava/Documents/big/bigfile.mp4';
const rstream = fs.createReadStream(path,{highWaterMark:9000});
const wstream = fs.createWriteStream("/Users/amitsrivastava/Documents/big/second.mp4");
// rstream.on('data',chunk=>{
//     wstream.write(chunk);
// })
// rstream.on('end',()=>console.log('file copied...'));
rstream.pipe(wstream);