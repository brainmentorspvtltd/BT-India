import path from 'path';
import dotenv from 'dotenv';
import fs from 'fs';
dotenv.config();
export function isStaticFile(url='index.html'){
  
    
    const extensions = [".html", ".css", ".png", ".jpeg",".jpg",".ico",".js"];
    const ROOT_DIR = process.env.BASE_PATH;
    const fullPath = path.join(ROOT_DIR,'public', url);
    const extension = path.extname(fullPath);
    return extensions.indexOf(extension)>=0;

}

export function serveFile(url='index.html', response){
    if(url.endsWith('.ico')){
        response.end();
        return ;
    }
    const ROOT_DIR = process.env.BASE_PATH;
    const fullPath = path.join(ROOT_DIR,'public', url);
    const readStream = fs.createReadStream(fullPath);
    readStream.pipe(response);
}