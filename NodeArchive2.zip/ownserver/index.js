import http from 'http';
import https from 'https';
import fs from 'fs';
import { isStaticFile, serveFile } from './serve-static.js';
import dotenv from 'dotenv';
dotenv.config();
function handleRequestAndResponse(request, response){
    //console.log('URL is ', request.url);
    const URL = request.url;
    const method = request.method;
    console.log('Request is ', URL);
    if(URL === '/'){
        console.log('HOme... ', URL);
        if(isStaticFile()){
        serveFile(undefined, response);
        }
    }
    else if(isStaticFile(URL)){
        serveFile(URL, response);
    }
    // Dynamic Content
    else if(URL ==='/login' && method == 'POST' ){
        let postData = '';
        request.on('data',chunk=>{
            postData+=chunk;
        });
        request.on('end',()=>{
            const url = new URLSearchParams(postData);
            const userObject = {};
            for(let e of url.entries()){
                console.log(e);
                userObject[e[0]] = e[1];
            }
            console.log('User Object ', userObject);
            if(userObject.userid===userObject.pwd){
                response.write('Welcome ' + userObject.userid);
            }
            else{
                response.write('Invalid Userid or Password');
            }
            response.end();
        })
        //response.write('Login....');
        
    }
    else if(URL=='/dashboard'){
        response.write('DashBoard');
        response.end();
    }
    else if(URL =='/heavy-task'){
        for(let i = 1; i<=100000; i++){
            for(let j = 1; j<=500000; j++){

            }
        }
        response.write('Heavy Task Done...');
        response.end();
    }
    else{
    response.writeHead(404,{contentType:'text/html'});
    response.write('<h1>OOPS U Type Something Else</h1>');
    response.end();
    }

}
const path = process.env.BASE_PATH+"/cert"
const httpsOptions = {
        key: fs.readFileSync(path+"/key.pem"),
        cert:fs.readFileSync(path+"/cert.pem")
}
const server = https.createServer(httpsOptions,handleRequestAndResponse);
server.listen(1234,(err)=>{
    if(err){
        console.log('Server Crash ', err);
    }
    else{
        console.log('Server Up and Running '
        , server.address().port);
    }
})