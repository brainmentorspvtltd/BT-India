// console.log(arguments);

// function(exports, require, module, __filename, __dirname){
//     var x= 10;
// }