import http from 'http';
function handleRequestAndResponse(request, response){
    response.writeHead(200,{contentType:'text/html'});
    response.write('<h1>Hello Client... </h1>');
    response.end();

}
const server = http.createServer(handleRequestAndResponse);
server.listen(1234,(err)=>{
    if(err){
        console.log('Server Crash ', err);
    }
    else{
        console.log('Server Up and Running '
        , server.address().port);
    }
})