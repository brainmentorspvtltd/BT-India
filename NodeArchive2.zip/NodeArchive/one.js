//console.log('Current Process is ', process);
//process.env.UV_THREADPOOL_SIZE=8;
const fs = require('fs'); // default common js
console.log('Hello Node');

fs.readFile('/Users/amitsrivastava/Documents/node-codes-bechtel/event-loop.js', (err,buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('Another File ', buffer.toString());
    }
});
fs.readFile(__filename, (err,buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('Data ', buffer.toString());
    }
});
throw new Error('Error');
console.log('Code Ends '); 
