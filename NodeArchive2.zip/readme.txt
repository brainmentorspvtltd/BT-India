Infinite Server (Always Listen Request) - Done
Handle Request and give Response - Done
Static Content Serve - Done
Dynamic Content Serve - Done
Routing  - Done
Redirection - Pending
Custom Error Handling - Done
GET (Pending), POST, PUT , Delete - Done
HTML (Done), JSON , XML Serve
http , https - Done

****************************************************
Load Testing (Mocking)
Clusters (Multiple Process)
LoadBalancer, IPC
CLI

********************************************
Express, LoadBalancer, DB Connect, Node TS,
Auth , Session, Token Handling, Logs (Server Logs,
 Appliction Logs)
Rate Limiter, CORS, Helmet, Nginx
NPM Version