const e = require('events');
var y = new e.EventEmitter();
y.on('data', (value)=>"");
y.on('data', chunk=>console.log('Chunk is ', chunk));
module.exports =y;