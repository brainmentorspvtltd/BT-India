import { Route, Routes } from "react-router-dom"
import { View } from "../../modules/contact/components/View"
import { Add } from "../../modules/contact/components/Add"
import { Error } from "./Error"


export const Main = () => {
  return (
    <div>
        <Routes>
            <Route path="/" element={<View/>}/>
            <Route path = "/add-contact" element={<Add/>}/>
            <Route path="*" element={<Error/>}/>
        </Routes>
    </div>
  )
}
