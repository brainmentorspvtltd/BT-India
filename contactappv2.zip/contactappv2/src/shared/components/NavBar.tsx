
import { NavLink } from 'react-router-dom'

export const NavBar = () => {
  return (
    <div>
        <NavLink to="/">View all</NavLink>
        <br/>
        <NavLink to="/add-contact">Add Contact</NavLink>
        <br/>
        <NavLink to="/delete-contact">Delete Contact</NavLink>
        <br/>
        <NavLink to="/update-contact">Update Contact</NavLink>
    </div>
  )
}
