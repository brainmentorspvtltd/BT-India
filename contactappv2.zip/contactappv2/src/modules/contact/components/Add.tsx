import { TextField, Button } from "@mui/material"
import { useRef } from "react"
import { useDispatch, useSelector } from "react-redux";
import { add } from "../redux/contact-slice";

export const Add = () => {
  const nameRef = useRef<HTMLInputElement>();
  const phoneRef = useRef<HTMLInputElement>();   
  const dispatch = useDispatch();
  const appState = useSelector((state)=>state);
  console.log('App State is ', appState.contactReducer.contacts);
  const addContact = ()=>{
        const contactObject = {
            name:nameRef.current?.value,
            phone:phoneRef.current?.value
        }
        console.log('Contact Object ', contactObject);
        dispatch(add(contactObject));

  }  
  return (
    <>
    <TextField inputRef = {nameRef}  label="Name" variant="outlined" />
    <TextField inputRef={phoneRef}  label="Phone" variant="outlined" />
    <br/>
    <Button onClick={addContact} variant="contained">Add</Button>
    </>
  )
}
