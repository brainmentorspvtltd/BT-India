
import { Header } from '../../../shared/components/Header'
import { Add } from '../components/Add'

import { Container, Grid } from '@mui/material'
import {NavBar} from '../../../shared/components/NavBar';
import { Main } from '../../../shared/components/Main';
export const ContactPage = () => {
  return (
    <Container>
        <Header/>
        <Grid container spacing={2}>
                <Grid item xs={4}>
                    <NavBar/>   
                </Grid>
                <Grid item xs={8}>
                <Main/>
                </Grid>   
          </Grid>      

    
    </Container>
  )
}
