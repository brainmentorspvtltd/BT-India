import { createSlice } from "@reduxjs/toolkit";


type contact = {name:string, phone:string};
const myInitState:{contacts:contact[], total :number} = {contacts:[], total :0}; 


 const contactSlice = createSlice({
    name:'contactSlice',
    initialState:myInitState,
    reducers:{
        add(state, action){
            console.log('PayLoad Data is ',action.payload );
             state.contacts.push(action.payload); // state updated   
        },
        view(state, action){

        },
        remove(state, action){

        },
        update(state, action){

        }
    }
})
//export const w = contactSlice.reducer;
export default contactSlice.reducer;
export const {add, view, remove, update} = contactSlice.actions;