import logo from './logo.svg';
import './App.css';
import { YouTube } from './components/YouTube';

function App() {
  return (
    <YouTube/>
  );
}

export default App;
