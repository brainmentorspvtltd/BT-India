import axios from 'axios';
const getVideos = ()=>{
    const URL = 'https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics%2Cplayer&chart=mostPopular&key=AIzaSyCMM_6pbLrcNVQou2T4_fVg2opgy1vqWec';
    const promise = axios.get(URL);
    return promise;
}
export default getVideos;