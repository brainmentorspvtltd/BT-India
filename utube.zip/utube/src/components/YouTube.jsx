import { useState } from "react";
import { useEffect } from "react"
import getVideos from "../services/api-client";

export const YouTube = ()=>{
    const [isLoading, setLoading] = useState(true);
    // Hook LifeCycle Hook
    // Mount
    // Update
    // UnMount
    // const [a, setA] = useState(0);
    // const [b, setB] = useState(0)
   


   useEffect(()=>{
    const p= getVideos();
    p.then(data=>{
        setLoading(false);
        console.log('Video are ', data);
    }).catch(e=>console.log('Error is ', e));
    console.log('Mount Phase');
       // console.log('Update Call');
        // return function(){
        //     console.log('Un Mount Call');
        // }
    },[]);
    return (<h1>{isLoading?'Loading':'Videos'}</h1>)
}