const AppConstants ={
    ROUTES:{
        USER_ROUTES:{
            PROFILE :'/profile',
            REGISTER:'/register'
        }
    }
}
export const USER_ROUTES = AppConstants.ROUTES.USER_ROUTES;