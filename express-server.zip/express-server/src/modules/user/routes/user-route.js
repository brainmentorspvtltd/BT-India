import express from 'express';
import { profile, register, history } from '../controllers/user-controller.js';
import { USER_ROUTES } from '../../../shared/utils/app-constants.js';
export const userRoutes = express.Router();
userRoutes.post(USER_ROUTES.REGISTER,register)
userRoutes.get(USER_ROUTES.PROFILE, profile);
userRoutes.get('/history/:username/:date', history);