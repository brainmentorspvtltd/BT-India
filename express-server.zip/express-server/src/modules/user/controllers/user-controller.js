import { messages } from "../../../shared/i18n/en.js";

export const history = (request, response)=>{
        const data  = request.params;
        console.log('Data is ', data);
        response.json({message:'User History'+data.username });
}

export const profile = (request, response)=>{
    const data = request.query;
    console.log('Data is ', data);
    response.send(`<h2>${messages.profile_message} ${data.userid}</h2>`);
}
export const register = (request, response)=>{
    const postBody = request.body;
    console.log('Post Body ', postBody);
    response.status(200).json({message:messages.register_message});
    //response.send(`<h2>${messages.register_message}</h2>`);
}
