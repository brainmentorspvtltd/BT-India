import express from 'express';
import chalk from 'chalk';
import { userRoutes } from './src/modules/user/routes/user-route.js';
import { error404 } from './src/shared/middlewares/404.js';
const app = express(); 
// middleware is just a function
// function(request, response, next){

//}

app.use(express.static('public'));
app.use(express.json());
app.use('/', userRoutes);

app.use(error404);

const server = app.listen(1234, err=>{
    if(err){
        console.log(chalk.red.bold('Server Crash '), err);
    }
    else{
        console.log(chalk.greenBright.italic.underline('Server Up and Running '), server.address().port);
    }
})