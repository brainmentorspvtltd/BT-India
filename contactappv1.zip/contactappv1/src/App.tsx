

import { ContactPage } from './modules/contact/pages/ContactPage'

function App() {
  return (<ContactPage/>)
}

export default App
