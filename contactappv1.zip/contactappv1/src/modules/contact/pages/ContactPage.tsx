
import { Header } from '../../../shared/components/Header'
import { Add } from '../components/Add'
import { View } from '../components/View'
import { Container, Grid } from '@mui/material'
export const ContactPage = () => {
  return (
    <Container>
        <Header/>
        <Grid container spacing={2}>
                <Grid item xs={4}>
                     Click to Add   
                </Grid>
                <Grid item xs={8}>
                <Add/>
                </Grid>   
          </Grid>      

    
    </Container>
  )
}
