import { TextField, Button } from "@mui/material"

export const Add = () => {
  return (
    <>
    <TextField id="outlined-basic" label="Name" variant="outlined" />
    <TextField id="outlined-basic" label="Phone" variant="outlined" />
    <br/>
    <Button variant="contained">Add</Button>
    </>
  )
}
