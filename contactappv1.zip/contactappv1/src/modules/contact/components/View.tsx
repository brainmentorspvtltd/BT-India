import { TableBody, TableContainer, Table, 
    TableHead, TableRow, TableCell, Paper } from "@mui/material"


export const View = () => {
  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Phone</TableCell>
            </TableRow>
            </TableHead>
            <TableBody>

            </TableBody>
            </Table>
            </TableContainer>
  )
}
