class Singer{

    constructor(public name:string , public title:string , public photo:string, public audio:string){
    }

    // name:string;
    // title:string;
    // photo:string;
    // audio:string;
    // constructor(name:string , title:string , photo:string, audio:string){
    //     this.name = name;
    //     this.title = title;
    //     this.photo = photo;
    //     this.audio = audio;
    // }
}
export default Singer;