export const Button = ({lbl, fn})=>{
    console.log('Button Call');
    return (<button onClick={fn} className="btn btn-primary">{lbl}</button>)
}