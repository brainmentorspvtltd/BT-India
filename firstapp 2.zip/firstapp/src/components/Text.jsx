export const Text = ({msg, val})=>{
    console.log('Text Call');
    return (<h1 className="alert alert-info text-center">{msg} {val} </h1>)
}