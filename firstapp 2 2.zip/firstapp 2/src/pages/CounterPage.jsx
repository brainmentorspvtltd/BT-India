import { useState } from "react"
import { Button } from "../components/Button"
import { Text } from "../components/Text"

export const Counter = ()=>{
    console.log('Counter Call');
    //let count = 0; // Data
    // Hook (Additional Feature)
    const [count, setCount] = useState(0);
    const plus =()=>{
        //count++;
        
        setCount(count + 1  ); //Async Re-rendering (Counter will call again)
        console.log('Plus call ', count);
    }
    const minus = ()=>{
        //count--;
        setCount(count - 1);
        console.log('Minus Call ', count);
    }
    return (<div>
        <Text val="" msg="Counter App"/>
        <Text val={count} msg="Count Value is "/>
        <Button fn = {plus} lbl = "+"/> &nbsp;
        <Button fn = {minus} lbl ="-"/>
    </div>)
}