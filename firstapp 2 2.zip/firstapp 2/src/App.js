// First Component

import React from "react";
import { Second } from "./components/Second";
import { Counter } from "./pages/CounterPage";

// Arrow Fn (Pure Fn)
const App = ()=>{
  return (<Counter/>)
  // return (<div>
  //   <h1>Hello React JS</h1>
  //   <h2>Hi React JS</h2>
  //   <Second x = "10" y = "20"/>
  //   </div>);
  //React.createElement('h1',)
  //return React.createElement('div', null, React.createElement('h1',null, 'Hi React JS'),React.createElement('h2', null, 'Hello React JS') ) ;
  
  
}
export default App;