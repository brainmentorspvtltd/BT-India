var a:number = 10; // Explicit Type
var b:number;
b = 20;
var c = 30; // Type Inference / Implicit Type
var d:string = "Amit";
var e = "shyam";
var t:boolean ;
//console.log(t);
var t2:bigint;
//var g1 = 22222n;

//var g2 = BigInt("222");
//g1 = "fhkdsj";
var arr = [10,20,30,"hgdfkj",true];
//var w1:number[] = [100,200,300,true,"Hello"];
var obj = {id:1001, name:'Ram'}; // Type Inference
var obj2:{id:number, name:string, age:number} ={id:111, name:'RR', age:22}; 
//obj.salary = 11111;
console.log(obj, obj2);
var a2:number = 100;


