// any vs unknown
var r;

var w:any = 100; // i dont care the value
w ="fhdk";
w = [10,20];
w = {id:1001}
w = true;
var k:boolean = w;

var w2:unknown; // i dont know
w2 = 10;
w2 = "ghd";
w2 = [100,200];
w2 = true;
//k = w2;

var w3:unknown;
w3 = w2;

var w4:any;
w4 = w2;
