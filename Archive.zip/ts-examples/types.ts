function printError(message):never{
    throw new Error(message);
}
function output():number{
    return 1;
}
var e:number = output();
function show():void{
    try{

    }
    catch(err){
        printError(err.message);
       //throw new Error("gdkjfghkjdfh");
    }
}

