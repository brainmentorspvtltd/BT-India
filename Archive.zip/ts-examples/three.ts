// tuples
var record:[number, string, boolean] = [1001,'Ram', true];
console.log(record[0], record[1], record[2]);
console.log(record);
var obj : {id:number, name:string, att:true} ={id:1001, name:'Ram', att:true};

var g1:number = 1000;
//g1 = "hgfjkd";

var g2:any ;

var r:number|string|boolean = true;
r = 1000;
r = "abcd";
//r = [10,20];

function show2(x:number|string):number|string{
    //return "20";
    //return true;
    return 10;
}