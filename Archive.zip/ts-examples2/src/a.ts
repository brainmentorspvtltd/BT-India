function show(x:number=0, y:number=0):void{
    console.log("I am Show ",x,y );

}



show(10,20);
show();