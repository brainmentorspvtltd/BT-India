interface IPlayer{
    walk():void;
    jump():void;

}
class RedPlayer implements IPlayer{
    walk(): void {
        
    }
    jump(): void {
        
    }
}
abstract class Person{
    constructor(public age:number,city:string){

    }
     abstract print():void;
}
class Employee extends Person{
    // private id:number;
    // private name:string;
    // constructor(id:number, name:string){
    //     this.id =id;
    //     this.name = name;
    // }
    // ShortHand
    constructor(private id:number, private name:string){
        super(22, 'Delhi');
        // this.id =id;
        // this.name = name;
    }

    print():void{
        console.log(`Id ${this.id} Name ${this.name}`);
    }
}
class FullTimeEmployee extends Employee{
    print():void{
        super.print();
        console.log(`Full Time`);
    }
}

var tom:Employee = new Employee(1001, "Tom");
tom.print();