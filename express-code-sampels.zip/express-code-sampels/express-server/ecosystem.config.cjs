module.exports = {
  "apps" : [{
    "name"       : "express-server-demo-cluster",
    "script"     : "./app.js",
    "instances"  : "max",
    "exec_mode"  : "cluster",
    "max_memory_restart": '30M'

    
  }]
}
