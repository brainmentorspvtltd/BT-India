import express from 'express';
import chalk from 'chalk';
import { userRoutes } from './src/modules/user/routes/user-route.js';
import { error404 } from './src/shared/middlewares/404.js';
import { apiLimiter } from './src/shared/middlewares/rate-limit.js';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import morgan from 'morgan';
import logger from './src/shared/utils/app-logs.js';
import { loadLogPath } from './src/shared/utils/server-logs.js';
import { prepareConnection } from './src/shared/db/connection.js';
dotenv.config();
const log = logger('app.js');
process.on('uncaughtException',err=>{
    // Send Email 
    console.log('UnCaught Exception ', err);
})

process.on('exit',()=>{

})

const app = express(); 
// middleware is just a function
// function(request, response, next){

//}
app.use(morgan('combined',{stream:loadLogPath()}))
console.log('App Start');   
app.use(cors()); 
app.use(helmet({
    contentSecurityPolicy:false
}));
app.use('/', apiLimiter) ;  
app.use(express.static('public'));
app.use(express.json());
app.use('/', userRoutes);

app.use(error404);

const server = app.listen(process.env.PORT || 1111, err=>{
    if(err){
        log.error('Server Crash');
        console.log(chalk.red.bold('Server Crash '), err);
    }
    else{
        prepareConnection();
        log.debug("Server Up and Running....");
        console.log(chalk.greenBright.italic.underline('Server Up and Running '), server.address().port);
    }
})
