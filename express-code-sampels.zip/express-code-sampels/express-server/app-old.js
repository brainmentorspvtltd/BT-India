import express from 'express';
import chalk from 'chalk';
import { userRoutes } from './src/modules/user/routes/user-route.js';
import { error404 } from './src/shared/middlewares/404.js';
import cluster from 'cluster';
import os from 'os';
console.log('IsMaster ',cluster.isPrimary);
const app = express(); 
// middleware is just a function
// function(request, response, next){

//}
if(cluster.isPrimary){
    const len = os.cpus().length;
    console.log('CPU Len ', len);
    for(let i = 1; i<=len; i++){
        cluster.fork();
        cluster.on('fork', worker=>{
            console.log('Worker ', worker.pid);
            worker.on('message', val=>{
                
            })
        })
    }
   
    // cluster.fork();
    // cluster.fork();
    // cluster.fork();
    // cluster.fork();
}
else{
    console.log('Process Id ',cluster.worker.process.pid);
    console.log('Worker ', cluster.isWorker, 'Worker id ', cluster.worker.id);
app.use(express.static('public'));
app.use(express.json());
app.use('/', userRoutes);

app.use(error404);

const server = app.listen(1234, err=>{
    if(err){
        console.log(chalk.red.bold('Server Crash '), err);
    }
    else{
        console.log(chalk.greenBright.italic.underline('Server Up and Running '), server.address().port);
    }
})
}