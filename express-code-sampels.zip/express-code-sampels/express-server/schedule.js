import nodecron from 'node-cron';
const cronExpression = "*/2 * * * *";
nodecron.schedule(cronExpression,()=>{
    console.log('Logic Run Every 2 Mins');
});
console.log('Scheduler Start...');