import mongoose from "mongoose";
export function prepareConnection(){
const promise = mongoose.connect(process.env.DB_URL,{maxPoolSize:5});
promise.then(data=>{
    console.log('Connection Build SuccessFully');
}).catch(err=>{
    console.log('Error During Connection ', err);
})
}
export default mongoose;