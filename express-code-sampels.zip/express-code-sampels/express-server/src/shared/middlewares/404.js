// 404 middleware
export const error404 = (request, response)=>{
    response.send('OOPS U Type Wrong URL....');
   
}