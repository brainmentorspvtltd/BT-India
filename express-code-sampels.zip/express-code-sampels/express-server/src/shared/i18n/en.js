export const messages = {
    profile_message:"User Profile",
    register_message:"Register SuccessFully"
}