import winston from 'winston';
const {combine, label, timestamp, printf} = winston.format;
const customFormat = printf(({level, message, label, timestamp})=>{
    return `${timestamp} [${label}] ${level} : ${message}`;
})

export default function(moduleName){
    const BPATH =`${process.env.BASE_PATH}`;
    return winston.createLogger({
        level:'debug',
        format:combine(label({label:moduleName}),timestamp(), customFormat),
        transports:[
            new winston.transports.File({
                filename:BPATH+'/logs/debug.log',
                level:'debug',
                maxsize:20*1024*1024,
                maxFiles:5
            }),
            new winston.transports.File({
                filename:BPATH+'/logs/error.log',
                level:'error',
                maxsize:20*1024*1024,
                maxFiles:5
            })
        ]
    })
}