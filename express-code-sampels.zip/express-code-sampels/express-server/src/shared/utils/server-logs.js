import fs from 'fs';
import path from 'path';
export function loadLogPath(){
const BPATH =`${process.env.BASE_PATH}`;
console.log('Base Path ',BPATH);
const fullPath = path.join(BPATH,'logs','server.log')
 return  fs.createWriteStream(fullPath,{interval:'7d'});
}