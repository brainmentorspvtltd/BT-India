import jsonwebtoken from 'jsonwebtoken';
const secret = 'thisissecret';
// Prepare Token and send to FrontEnd
const createToken=(userid)=>{
    return jsonwebtoken.sign({
        'uid':userid
    }, secret, {expiresIn:'1h'})
}
// Front End Pass a Token
const verifyToken = (token)=>{
    const decode = jsonwebtoken.verify(token, secret);
    if(decode){
    console.log('Token decode ', decode.uid);
        return true;
}
else{
    return false;
}

}

const token = createToken('amit');
console.log('Token is ', token);
console.log(verifyToken(token)?"Verified":"Not Verified");