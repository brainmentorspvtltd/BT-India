export class User{
    constructor(userid, password){
        this.userid = userid;
        this.password = password;
    }
}