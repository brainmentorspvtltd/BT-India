import { messages } from "../../../shared/i18n/en.js";
import { User } from "../dto/user.js";
import { UserModel } from "../models/user-model.js";
// import io from '@pm2/io';
export const history = (request, response)=>{
        const data  = request.params;
        console.log('Data is ', data);
        response.json({message:'User History'+data.username });
}

export const profile = (request, response)=>{
    const data = request.query;
    console.log('Data is ', data);
    // try{
    // throw new Error('Error in Profile....');
    // }
    // catch(err){
    //     io.notifyError(new Error('Notification failed'), {
    //         // or anything that you can like an user id
    //         custom: {
    //           user: "MyError"
    //         }
    //       })
    // }
    response.send(`<h2>${messages.profile_message} ${data.userid}</h2>`);
}
export const register = async (request, response)=>{
    const postBody = request.body;
    console.log('Post Body ', postBody);
    // Joi 
    const user = new User(postBody.userid, postBody.password);
    const doc = await UserModel.create(user);
    response.status(200).json({message:messages.register_message, doc:doc});
    //response.send(`<h2>${messages.register_message}</h2>`);
}

export const bigTask = (request, response)=>{
    for(let i = 1; i<=100000; i++){
        for(let j = 1; j<=500000; j++){}

    }
    response.json({message:'Big Task Done...'});
}
