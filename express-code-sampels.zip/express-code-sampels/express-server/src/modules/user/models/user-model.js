import mongoose from '../../../shared/db/connection.js';
const {Schema, SchemaTypes } = mongoose;
const userSchema = new Schema({
    'userid':{type:SchemaTypes.String, required:true, unique:true, minLength:3, maxLength:10, trim :true, lowercase:true},
    'password':{type:SchemaTypes.String, validate:{
        validator:function(value){
            const min = 3;
            const max = 8;
            if(value>=min && value<=max){
                return false;
            }
        },message:function(props){
            return props.path+' Value '+props.value+' is illegal'
        }
    }}
})
export const UserModel = mongoose.model('users', userSchema);
