import bcrypt from 'bcrypt';
const SALT = 10; // Rounds
const plainPassword = "amit";
const hashPwd = bcrypt.hashSync(plainPassword,SALT);
console.log('Hash Password ', hashPwd);
const result = bcrypt.compareSync(plainPassword,hashPwd);
console.log(result?"Same ":"not Same");