export const logic = (num)=>{
    console.log('Logic Start...');
    for(let i = 1; i<=100000; i++){
        for(let j = 1; j<=500000; j++){

        }
    }
    console.log('Logic Ends .....', num);
    return num%2==0?num*num:num**3;
}