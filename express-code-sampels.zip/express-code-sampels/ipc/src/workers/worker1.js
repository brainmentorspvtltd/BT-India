import { logic } from "../services/logic.js";
console.log('I am the Child1 Process ', process.pid);
// child process has a listener
process.on('message',num=>{
    console.log('Rec Request ', process.pid, 'Num is ', num);
    const result = logic(num); // Wait Happen Here
    // send back this result to the master
    // process - contains current process not parent process
    process.send(result); // Send Result to the parent process
})
export default process;