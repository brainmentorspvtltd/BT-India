import express from 'express';

export const routes = express.Router();
// http://localhost:1234/welcome?num=2
routes.get('/welcome',(request, response)=>{
    const num = request.query.num; // ?num=2
    //const result = logic(num); // Big Wait (Bad Way)
    // Delegate to the Worker
    // process - current process (master) (not child)
    process.send(num);  // Async (No Wait) // send (Event Emit) and Then Delegate to the Listener
    response.send('Request Send to the Workers '+num);
});
