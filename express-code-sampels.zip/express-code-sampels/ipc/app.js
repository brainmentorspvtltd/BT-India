import express from 'express';

import  { routes } from './src/routes/route.js';

import child_process from 'child_process';
import cluster from 'cluster';
//import worker_threads from 'worker_threads';

if(cluster.isPrimary){
// Create Child Process
const worker1 = child_process.fork('./src/workers/worker1.js');
const worker2 = child_process.fork('./src/workers/worker2.js');
console.log('Worker1 ', worker1.pid);
console.log('Worker2 ', worker2.pid);
// Fork Done
cluster.on('fork', worker=>{
    // worker - Main Worker
    worker.on('message', val=>{
        console.log('Master Process Listener ', process.pid);
        worker1.send(val);
        worker2.send(val);
        // if(val%2==0){
        // worker1.send(val);
        // }
        // else{
        // worker2.send(val);
        // }
    })
})

worker1.on('message', val=>{
    console.log('Rec Result from Worker1 ', worker1.pid, val);
});
worker2.on('message', val=>{
    console.log('Rec Result from Worker2 ', worker2.pid, val);
})
cluster.fork(); // Fork the App
}
else{
    const app = express();
    app.use('/', routes);
const server = app.listen(1234,err=>{
    if(err){
        console.log('Server Crash ', err);
    }
    else{
        console.log('Server Up and Running ', server.address().port);
    }
})
}