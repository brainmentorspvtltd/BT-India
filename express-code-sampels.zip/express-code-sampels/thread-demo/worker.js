// Prepare Thread & Delegate Logic
import worker_threads from 'worker_threads';
import { logic } from './logic.js';
const {Worker, isMainThread, parentPort} = worker_threads;
if(isMainThread){
    console.log('I am the Main Thread ', isMainThread);
const path = '/Users/amitsrivastava/Documents/express-code-sampels/thread-demo/worker.js';
const worker = new Worker(path);
worker.on('message',msg=>{
    console.log('Rec Data from Thread ', msg);
})
}
else{
    console.log("I am not Main Thread");
    parentPort.postMessage('Logic Start');
    const result = logic(5);
    parentPort.postMessage('Result is '+result);

}


