export const Button = ({val, fn})=>{
    return (<button onClick={fn} className="btn btn-primary me-2">{val}</button>)
}