import { useState } from "react"
import { Form } from "../components/Form"
import List from "../components/List"
import { Text } from "../widgets/Text"

export const BillingAppPage = ()=>{
    const [products, setProducts] = useState([]);
    const collectData = (product)=>{
        const clone= [...products];
        clone.push(product);
        setProducts(clone);
            //console.log('Product data ', product);
    }
    const compute = ()=>
        products.reduce((sum, currentProduct)=>sum + (currentProduct.price * currentProduct.quantiy), 0);
    
    return (<div className = 'container'>
       
        <Form collectdata = {collectData}/>
        <br/>
        <Text msg = "Total Records " val = {products.length}/>
        <Text msg = "Mark Records " val = "0" />
        <List products = {products}/>
        <Text msg="Grand Total" val = {compute()}/>
    </div>)
}