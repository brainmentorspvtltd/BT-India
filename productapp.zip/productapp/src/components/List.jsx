const List = ({products})=>{
        console.log('Products ', products);
    return (<table className="table table-bordered">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Amount</th>
                <th>Operations</th>
            </tr>
        </thead>
        <tbody>
            {products.map((product,index)=><tr className="" key={index}>
                <td>{index+1}</td>
                <td>{product.name}</td>
                <td>{product.price}</td>
                <td>{product.quantiy}</td>
                <td>{product.price * product.quantiy}</td>
                <td><i class="fa fa-trash" aria-hidden="true"></i></td>

            </tr>)}
        </tbody>
    </table>)
}
export default List;