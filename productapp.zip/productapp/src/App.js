import logo from './logo.svg';
import './App.css';
import { Form } from './components/Form';
import { BillingAppPage } from './pages/BillingAppPage';

function App() {
  return (
    <BillingAppPage/>
  );
}

export default App;
