const mongoose = require("mongoose");

const permissionSchema = new mongoose.Schema({
  id: String,
  name: String,
  description: String,
  isActive: Boolean,
});

const permissionModel = mongoose.model("Permission", permissionSchema);

module.exports = permissionModel;
