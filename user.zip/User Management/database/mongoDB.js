const mongoose = require('mongoose');
const db = 'mongodb+srv://skillrisers:skillrisers@cluster0.gbjkb4e.mongodb.net/User-Management?retryWrites=true&w=majority';

module.exports = mongoose.connect(db, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => {
    console.log("Connected");
  })
  .catch((error) => {
   console.log("Failed", error);
  });
