const logoutController = async (req, res) => {
  // Perform any logout logic here

  return res.status(200).json({ message: "Logout successful" });
};

module.exports = logoutController;
