const UserModel = require("../models/userModel");

const loginController = async (req, res) => {
  const { username, password } = req.body;
  console.log("req.body", req.body);
  try {
    const user = await UserModel.findOne({ name: username });

    if (user && user.password === password) {
      const users = await UserModel.find();
      console.log('====================================');
      console.log("List of users is : ", users);
      console.log('====================================');
      return res.status(200).render("dashboard", { userList: users });
    }
    return res.status(401).json({ message: "Invalid credentials" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
};

module.exports = loginController;
