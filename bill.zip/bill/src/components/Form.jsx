import { useRef } from "react"
import { Button } from "../widgets/Button"
import { Text } from "../widgets/Text"
import { TextField } from "../widgets/TextField"

export const Form = ({collectdata, markCount, deleteRecords})=>{
    const name = useRef();
    const price = useRef();
    const quantiy = useRef();
    const add = ()=>{
        const product = {
            "name":name.current.value,
            "price":price.current.value,
            "quantiy":quantiy.current.value,
            "isMarked":false
            
        }
        collectdata(product);
        console.log('Add Call ',product);
    }
    return (
    <div>
        
    <Text msg="Billing App"/>    
    <TextField inputref ={name} lbl="Name"/>
    <TextField inputref ={price} lbl="Price"/>
    <TextField inputref ={quantiy} lbl="Quantity"/>
    <br/>
    <Button fn = {add} val="Add" />
    <Button fn = {deleteRecords} val="Delete" disable = {markCount==0}/>
    </div>
    )
}