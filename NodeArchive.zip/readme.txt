Infinite Server (Always Listen Request) - Done
Handle Request and give Response
Static Content Serve
Dynamic Content Serve
Routing
Redirection
Custom Error Handling
GET, POST, PUT , Delete
HTML, JSON , XML Serve
http , https

****************************************************
Load Testing (Mocking)
Clusters (Multiple Process)
LoadBalancer, IPC
CLI

********************************************
Express, LoadBalancer, DB Connect, Node TS,
Auth , Session, Token Handling, Logs (Server Logs,
 Appliction Logs)
Rate Limiter, CORS, Helmet, Nginx
NPM Version