import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
dotenv.config();
const dirName = process.env.BASE_PATH;
console.log('DirName ', dirName);
const fullPath =path.join(dirName, '/contents', 'score.txt')
//fs.watch(dirName)
fs.watchFile(fullPath,()=>{
    console.log('Match Score Change ');
    try{
    const data = fs.readFileSync(fullPath);
    console.log(data.toString());
    }
    catch(err){
        console.log('Fail to read a file ', err);
    }
})
console.log('Real time Score');