
// console.log('Hello Node ', arguments);
