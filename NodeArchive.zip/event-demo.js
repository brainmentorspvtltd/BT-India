// const e = require('events');
// var y = new e.EventEmitter();
// y.setMaxListeners(20);
const y = require('./listener');

y.emit('data', 'Amit');

