const fs = require('fs');
const path = '/Users/amitsrivastava/Documents/mern-23-dt/Day-27-HTMLEND-CSSStart-DAY-3/2023-09-27 19-12-46.mp4';
console.log('Code Start');
const stream = fs.createReadStream(path);
stream.on('open',()=>console.log('Stream Ready'));
stream.on('data', chunk=>console.log('Chunk is ',chunk));
stream.on('error',(err)=>console.log('Error in Stream ', err));
stream.on('end', ()=>console.log('Stream End'));

stream.on('close', ()=>console.log('Stream Close'));


// fs.readFile(path, (err, buffer)=>{
//     if(err){
//         console.log('Error ', err);
//     }
//     else{
//         console.log('Data ', buffer);
//     }
// })
console.log('Code Ends ');