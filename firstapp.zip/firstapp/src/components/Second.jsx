import React from "react";
import './Second.css';
export const Second = ({x,y})=>{
    const fruits = ['Apple', 'Orange', 'Mango'];
    const customers = [{id:1001,name:'Ram',balance:2222}, {id:1002,name:'Amit',balance:4222},{id:1003,name:'Shyam',balance:3222}]
    const username = "Amit";
    const condition = (z)=>{
        if(z>100){
            return (<p>100</p>)
        }
        else if(z<100 && z>50){
            return (<p>B/w 50 to 99</p>)
        }
        else{
            return (<p>Less than 50</p>)
        }
    }
    const myStyle = {
        color:'cyan',
        backgroundColor:'red'
    }
    console.log('Props is ', x,y, typeof x, typeof y);
    return (
    <>
    {customers.map(customer=><p key={customer.id}>{customer.id} {customer.name} {customer.balance}</p>)}
        {fruits.map((fruit,index)=><p key={index}>{fruit}</p>)}
    {username && <p>Welcome {username}</p>}
    {condition(x*100)}
    {x>y?<p>X is Greater</p>:<p>Y is Greater</p>}
    <p className={parseInt(x)>parseInt(y)?'red':'green'}>Hi I am Second {x} {y}</p>
    <p style={myStyle}>Hi I am Second {x} {y}</p>
    </>
    )
}