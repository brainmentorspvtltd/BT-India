import React from 'react';
export const ProductContext = React.createContext({products:[],changeProducts:function(){}, total:0, mark:0, getProduct:function(){}, currentProduct:null})