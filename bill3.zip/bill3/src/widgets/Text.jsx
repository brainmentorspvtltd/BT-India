export const Text = ({msg, val})=>{
    return (<h3>{msg} {val}</h3>)
}